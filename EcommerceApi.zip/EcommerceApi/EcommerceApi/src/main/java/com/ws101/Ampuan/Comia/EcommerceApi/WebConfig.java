@Configuration
public class WebConfig implements WebMvcConfigurer {
    @Override
    public void addCorsMappings(CorsRegistry registry) {
        registry.addMapping("/api/v1/**")
                .allowedOrigins("http://localhost:5500") // Port ng Live Server mo
                .allowedMethods("GET", "POST", "PUT", "DELETE")
                .allowedHeaders("*");[cite: 5]
    }
}