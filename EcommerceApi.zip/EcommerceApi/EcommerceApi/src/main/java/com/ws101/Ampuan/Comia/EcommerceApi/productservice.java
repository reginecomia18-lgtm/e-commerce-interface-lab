@Service
public class ProductService {
    private final ProductRepository productRepository;

    public ProductService(ProductRepository productRepository) {
        this.productRepository = productRepository;
    }

    public List<Product> getAllProducts() {
        return productRepository.findAll();[cite: 5]
    }

    public Optional<Product> getProductById(Long id) {
        return productRepository.findById(id);[cite: 5]
    }

    public Product addProduct(Product product) {
        return productRepository.save(product);[cite: 5]
    }

    public boolean deleteProduct(Long id) {
        if (productRepository.existsById(id)) {
            productRepository.deleteById(id);
            return true;
        }
        return false;[cite: 5]
    }
}