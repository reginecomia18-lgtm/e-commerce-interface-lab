@Entity
@Table(name = "products")
@Getter @Setter @NoArgsConstructor @AllArgsConstructor
public class Product {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;[cite: 5]
    
    @Column(nullable = false)
    private String name;[cite: 5]
    
    private String description;
    private double price;
    private int stockQuantity;

    // Many-to-One relationship with Category
    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "category_id")
    private Category category;[cite: 5]
}