@CrossOrigin(origins = "http://localhost:5500")
@RestController
@RequestMapping("/api/v1/products")
public class ProductController {
    private final ProductService productService;

    public ProductController(ProductService productService) {
        this.productService = productService;
    }

    @GetMapping
    public ResponseEntity<List<Product>> getAllProducts() {
        return new ResponseEntity<>(productService.getAllProducts(), HttpStatus.OK);[cite: 25]
    }

    @PostMapping
    public ResponseEntity<Product> createProduct(@RequestBody Product product) {
        if (product.getPrice() <= 0 || product.getName() == null) {
            return new ResponseEntity<>(HttpStatus.BAD_REQUEST);[cite: 25]
        }
        Product savedProduct = productService.addProduct(product);
        return new ResponseEntity<>(savedProduct, HttpStatus.CREATED);[cite: 25]
    }
}